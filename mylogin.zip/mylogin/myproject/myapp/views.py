from django.shortcuts import render,redirect,HttpResponse
from django.contrib import messages
from django.views.decorators.cache import never_cache
# Create your views here.


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get("username")
        password = request.POST.get('password')

        if username == "adhil" and password == '123':
            request.session['username'] = username
            return redirect('home')
        else:
            return HttpResponse("username or password is incorrect")
    return render(request,'login.html')

#------------------------------------------------------------------

@never_cache
def home_view(request):
    if 'username' not in request.session:
        return redirect('login')
    return render(request,'home.html')

#-----------------------------------------------------------------------------

def logout_view(request):
    if 'username' in request.session:
        del request.session['username']
    
    return redirect('login')