string = 'adhil'
item = ''
for i in string:
    item = i+item

print(item)





