sen = 'all the huumans will die on the day'
new=sen.replace("die",'live')
print(new)

print(sen.capitalize())
print(sen.upper())
print(sen.title())

# -------utility methods-----------------------
print(sen.count('on'))
print(sen.strip())
print(sen.startswith('a'))