li = [1,2,3,4,5,6,7,8,9]

index = -1

while li:
    if index != (-len(li)-1):
        print(li[index])
        index-=1

   
