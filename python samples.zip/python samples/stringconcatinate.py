a='ali'
b='bai'
c=a+' '+b
print(c)

li = ['h','a','b','e','e','b']

result = ''.join(li)
print(result)