li = [1,2,3,4,5,6,7,8,9]
index = -1

for i in range(-1,(-len(li)-1),-1):
    print(li[i])


