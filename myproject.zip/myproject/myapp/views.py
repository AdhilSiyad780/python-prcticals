from django.shortcuts import render,redirect,HttpResponse
from django.views.decorators.cache import never_cache
from django.contrib.auth import authenticate,login,logout

# Create your views here.
@never_cache
def Login(request):
    if request.user.is_authenticated:
        return render(request,'home.html')          
    error=''                    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request,username=username,password=password)
        if user is not None:
             login(request,user)
             return render(request,'home.html')
        else:
            error = "username or password is incorrect"
    return render(request,"login.html",{"message": error})
    
#------------------------------------------------------------------
@never_cache
def home(request):
    if request.user.is_authenticated:
        return render(request,'home.html')
    return render(request,"login.html")
#-----------------------------------------------------------------------------
def Logout(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            logout(request)
            return redirect('Login')
        return redirect('home')
    return render(request,'login.html')   
# ------------------------------------------

   
   
   
       